public class Horista extends Funcionario {
    private Integer qtdHora;
    private Double valorHora;

    protected Horista(String cpf, String nome, Integer qtdHora, Double valorHora) {
        super(cpf, nome);
        this.qtdHora = qtdHora;
        this.valorHora = valorHora;
    }

    @Override
    public Double calcSalario() {
        return this.qtdHora * this.valorHora;
    }

    @Override
    public String toString() {
        return "Horista{" +
                (super.toString()) +
                ", qtdHora=" + qtdHora +
                ", valorHora=" + valorHora +
                ", Salario="+ this.calcSalario() +
                '}';
    }

    public Integer getQtdHora() {
        return qtdHora;
    }

    public Double getValorHora() {
        return valorHora;
    }
}
