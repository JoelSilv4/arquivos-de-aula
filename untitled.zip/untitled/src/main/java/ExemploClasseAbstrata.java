public class ExemploClasseAbstrata {
    public static void main(String[] args) {

        Vendedor v = new Vendedor("51022871846","Joel",20000.0,0.5);

        Horista h = new Horista("52933081653","Maria",200,30.0);

        System.out.println(v);
        System.out.println(h);

        Empresa e = new Empresa("Bandtec");

        e.adicionaFunc(v);
        e.adicionaFunc(h);

        e.exibeTodos();
        e.exibeVendedores();
        e.exibeTotalSalario();

    }

}
